﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubscriptionManager
{
    public  interface ISubscriptionPrices
    {
        double Monday { get;  }
        double Tuesday { get;  }
        double Wednesday { get;  }
        double Thursday { get;  }
        double Friday { get;  }
        double Saturday { get;  }
        double Sunday { get;  }

        string Code { get; }

        Double TotalCost();

    }
}
