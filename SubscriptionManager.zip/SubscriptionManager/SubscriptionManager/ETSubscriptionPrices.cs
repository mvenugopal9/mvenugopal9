﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubscriptionManager
{
    public class ETSubscriptionPrices : ISubscriptionPrices
    {
        public double Monday { get; private set; }
        public double Tuesday { get; private set; }
        public double Wednesday { get; private set; }
        public double Thursday { get; private set; }
        public double Friday { get; private set; }
        public double Saturday { get; private set; }
        public double Sunday { get; private set; }
        public string Code { get; private set; }

        public ETSubscriptionPrices(
            double mondayPrice,
            double tuesdayPrice,
            double wednesdayPrice,
            double thursdayPrice,
            double fridayPrice,
            double saturdayPrice,
            double sundayPrice
            )
        {
            Monday = mondayPrice;
            Tuesday = tuesdayPrice;
            Wednesday = wednesdayPrice;
            Thursday = thursdayPrice;
            Friday = fridayPrice;
            Saturday = saturdayPrice;
            Sunday = sundayPrice;
            Code = "ET";
        }

        public double TotalCost()
        {
            return Monday + Tuesday + Wednesday + Thursday + Friday + Saturday + Sunday;

        }

    }
}
