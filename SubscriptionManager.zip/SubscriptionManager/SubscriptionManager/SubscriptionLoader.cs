﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubscriptionManager
{
    public class SubscriptionLoader
    {
        public List<ISubscriptionPrices> GetAllSubscriptions()
        {
            var subscriptions = new List<ISubscriptionPrices>();

            subscriptions.Add(new TOISubscriptionPrices(3, 3, 3, 3, 3, 5, 6));
            subscriptions.Add(new HinduSubscriptionPrices(2.5, 2.5, 2.5, 2.5, 2.5, 4, 4));
            subscriptions.Add(new TOISubscriptionPrices(4, 4, 4, 4, 4, 4, 10));
            subscriptions.Add(new TOISubscriptionPrices(1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5));
            subscriptions.Add(new TOISubscriptionPrices(2, 2, 2, 2, 2, 4, 4));

            return subscriptions;
        }
    }
}
