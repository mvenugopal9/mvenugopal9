﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubscriptionManager
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SubscriptionLoader loader = new SubscriptionLoader();
            var subscriptions = loader.GetAllSubscriptions();
            string affordableSubscriptiosns = string.Empty;
            List<string> subs = new List<string>();
            Console.WriteLine("Please enter weekly budget and press enter:");
            Double.TryParse(Console.ReadLine(), out double budgetvalue);

            for (int i = 0; i < subscriptions.Count; i++)
            {
                for (int j = i + 1; j < subscriptions.Count; j++)
                {
                    if (subscriptions[i].TotalCost() + subscriptions[j].TotalCost() <= budgetvalue)
                    {
                        affordableSubscriptiosns = subscriptions[i].Code + subscriptions[j].Code;
                        subs.Add(affordableSubscriptiosns);
                    }
                }
            }

            foreach(string s in subs)
            {
                Console.WriteLine(s);
            }

        }
    }
}
